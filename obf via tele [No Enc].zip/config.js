// config.js
module.exports = {
    BOT_TOKEN: "7516504385:AAG4b8M7pLQzz01MtOq2sZ9Ors_Nw-iTgbE", 
    ADMIN_ID: 1999860807  
};